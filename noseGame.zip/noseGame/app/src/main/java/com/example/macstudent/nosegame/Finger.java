package com.example.macstudent.nosegame;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.util.Log;

public class Finger {


Bitmap image;
int xPosition;
int yPosition;
    int direction = -1;
private Rect hitbox;


    public Finger(Context context, int x, int y){

        this.image =  BitmapFactory.decodeResource(context.getResources(), R.drawable.finger01);

        this.xPosition = x;
        this.yPosition = y;

        Log.d("initialXposition: "," x: " + this.xPosition);

        this.hitbox = new Rect(this.xPosition,this.yPosition,this.xPosition + this.image.getWidth(),this.yPosition + this.image.getHeight());
    }

    public void updateFingerPosition(){


        this.xPosition = this.xPosition + 1;

        Log.d("2ndXposi: "," x: " + this.xPosition);

        this.hitbox.left = this.xPosition;
        this.hitbox.right = this.xPosition + this.image.getWidth();
       // this.updateHitbox();

        if (this.direction == 0) {
            // move down
            this.yPosition = this.yPosition - 5;
            this.updateHitbox();
        }
        else if (this.direction == 1) {
            // move up
            this.yPosition = this.yPosition + 5;
            this.updateHitbox();
        }


        Log.d("xxxx","ss" + xPosition);
    }

    public void updateHitbox() {
        // update the position of the hitbox
        this.hitbox.top = this.yPosition;
        this.hitbox.left = this.xPosition;
        this.hitbox.right = this.xPosition + this.image.getWidth();
        this.hitbox.bottom = this.yPosition + this.image.getHeight();
    }

    public Rect getHitbox() {
        return this.hitbox;
    }


    public void setXPosition(int x) {
        this.xPosition = x;
        this.updateHitbox();
    }
    public void setYPosition(int y) {
        this.yPosition = y;
        this.updateHitbox();
    }
    public int getXPosition() {
        return this.xPosition;
    }
    public int getYPosition() {
        return this.yPosition;
    }

    public Bitmap getBitmap() {
        return this.image;
    }

    public void setDirection(int i) {
        this.direction = i;
    }

}
