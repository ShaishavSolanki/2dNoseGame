package com.example.macstudent.nosegame;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class GameEngine extends SurfaceView implements Runnable {

    // screen size
    int screenHeight;
    int screenWidth;


    SurfaceHolder holder;
    Canvas canvas;
    Paint paintbrush;

    Bitmap noseImage;

    boolean gameIsRunning;
    boolean fingerIsMovingLeft = true;
    boolean fingerIsMovingRight = false;

    Point fingerPosition;

    Finger finger;
    // threading
    Thread gameThread;

    public GameEngine(Context context, int w, int h) {
        super(context);

        this.holder = this.getHolder();
        this.paintbrush = new Paint();

        this.screenWidth = w;
        this.screenHeight = h;

        Log.d("width","s" + screenWidth);


        this.setImages();




    }

    private void setImages() {

        this.noseImage = BitmapFactory.decodeResource(this.getResources(), R.drawable.nose01);

        //this.fingerImage = BitmapFactory.decodeResource(this.getResources(),R.drawable.finger01);

        finger = new Finger(this.getContext(),0,600);


    }




    @Override
    public void run() {
        while (gameIsRunning == true) {
            this.updatePositions();
            this.redrawSprites();
            this.setFPS();
        }
    }

    private void setFPS() {
    }

    int siz  =15;
    private void redrawSprites() {
        if (this.holder.getSurface().isValid()) {
            this.canvas = this.holder.lockCanvas();


            canvas.drawColor(Color.BLACK);
            canvas.drawBitmap(this.finger.getBitmap(), this.finger.getXPosition(), this.finger.getYPosition(), null);
            canvas.drawBitmap(this.noseImage,this.screenHeight/2,10,null);


            paintbrush.setColor(Color.WHITE);
            paintbrush.setTextSize(50);
            canvas.drawText("Nose Picked: 0",50,50,paintbrush);
            canvas.drawText("Nose Missed: 0",50,100,paintbrush);

            paintbrush.setColor(Color.RED);
            paintbrush.setStyle(Paint.Style.STROKE);
            paintbrush.setStrokeWidth(5);
            Rect fingerHitbox = finger.getHitbox();
            canvas.drawRect(fingerHitbox.left, fingerHitbox.top, fingerHitbox.right, fingerHitbox.bottom, paintbrush);
            this.holder.unlockCanvasAndPost(canvas);

        }
    }
    private void updatePositions() {


        finger.updateFingerPosition();
        if (finger.getXPosition() >= this.screenWidth) {


            fingerIsMovingLeft = false;
            fingerIsMovingRight = true;


            Log.d("sssssssss","a: "+ finger.xPosition);
            //reset the enemy's starting position to right side of screen
            // you may need to adjust this number according to your device/emulator


        }
        if (fingerIsMovingRight == true){


            finger.xPosition = finger.xPosition - 5;
            Log.d("11111111","a: "+ finger.xPosition);
            if (finger.xPosition == this.screenWidth){
                Log.d("fingerposititonnn","a: "+ finger.xPosition);
                fingerIsMovingLeft = true;
                fingerIsMovingRight = false;

            }
        }
        if (fingerIsMovingLeft == true){
            Log.d("moviun","x"+finger.xPosition);
            if (finger.xPosition == 0){
                fingerIsMovingRight = true;
            }
        }



    }


    public void pauseGame() {
        gameIsRunning = false;
        try {
            gameThread.join();
        } catch (InterruptedException e) {
            // Error
        }
    }

    public void startGame() {
        gameIsRunning = true;
        gameThread = new Thread(this);
        gameThread.start();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int userAction = event.getActionMasked();
        //@TODO: What should happen when person touches the screen?
        Log.d("touch","ass");
        if (userAction == MotionEvent.ACTION_DOWN) {
            // move player up
            this.finger.setDirection(1);
            finger.updateHitbox();
        }
        else if (userAction == MotionEvent.ACTION_UP) {
            // move player down
            this.finger.setDirection(0);
            finger.updateHitbox();
        }

        return true;
    }
}